<?php
$datasource = "pgsql:host=177.44.36.94; port=1998; dbname=sis_car_aluguel";
$user = "postgres";
$pass = "bd123";
$db = new PDO($datasource, $user, $pass);
?>




